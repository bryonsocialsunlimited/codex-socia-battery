export type CheckoutIntent = {
  outingId: string;
  priceType: "one-off" | "category-pass" | "all-access" | "discounted";
  bypassCode?: string;
};

export async function createCheckoutIntent(intent: CheckoutIntent) {
  const bypassAccepted = intent.bypassCode?.trim().toUpperCase() === "SOCIALBETA";

  return {
    provider: "mock-stripe",
    amountDue: bypassAccepted ? 0 : undefined,
    status: bypassAccepted ? "bypassed" : "ready_for_checkout",
    intent
  };
}
