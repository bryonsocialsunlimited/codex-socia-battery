import { AppShell } from "@/components/app-shell";
import { Button, Card, Pill, SectionHeader } from "@/components/ui";
import { outings } from "@/lib/mock-data";

export default function OutingsPage() {
  const upcoming = outings.slice(0, 3);
  const past = outings.slice(3, 5);

  return (
    <AppShell title="Outings" subtitle="Your upcoming, pending, and past Social Battery plans.">
      <div className="space-y-6">
        <Card>
          <div className="grid grid-cols-4 gap-2 text-center text-xs font-semibold text-mist">
            {["Upcoming", "Pending", "Past", "Credits"].map((tab, index) => (
              <span
                className={index === 0 ? "rounded-2xl bg-charge/15 px-2 py-3 text-charge" : "rounded-2xl bg-white/[0.06] px-2 py-3"}
                key={tab}
              >
                {tab}
              </span>
            ))}
          </div>
        </Card>

        <section>
          <SectionHeader eyebrow="Upcoming" title="Confirmed and forming" />
          <div className="space-y-4">
            {upcoming.map((outing, index) => (
              <Card key={outing.id}>
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <Pill tone={index === 2 ? "warning" : "good"}>
                      {index === 2 ? "Pending group assignment" : "Group confirmed"}
                    </Pill>
                    <h3 className="mt-3 text-lg font-bold text-white">{outing.title}</h3>
                    <p className="mt-2 text-sm text-mist">
                      {outing.dateLabel} at {outing.timeLabel} · {outing.venue}
                    </p>
                    <p className="mt-2 text-xs text-mist">
                      Ticket status: in-app delivery pending · Check-in opens near venue.
                    </p>
                  </div>
                  <span className="rounded-2xl bg-white/10 px-3 py-2 text-xs text-charge">
                    Chat opens 1 hour before
                  </span>
                </div>
                <Button className="mt-4 w-full" href={index === 0 ? "/groups/group-film-01" : `/outings/${outing.id}`} variant="secondary">
                  View details
                </Button>
              </Card>
            ))}
          </div>
        </section>

        <section>
          <SectionHeader eyebrow="Past" title="Feedback and friendship prompts" />
          <div className="space-y-4">
            {past.map((outing) => (
              <Card key={outing.id}>
                <h3 className="text-lg font-bold text-white">{outing.title}</h3>
                <p className="mt-2 text-sm text-mist">
                  Feedback window closes after day 4. Same-day completion earns highest points.
                </p>
                <Button className="mt-4 w-full" variant="secondary">
                  Complete feedback
                </Button>
              </Card>
            ))}
          </div>
        </section>
      </div>
    </AppShell>
  );
}
