import { OutingCard } from "@/components/outing-card";
import { SplashIntro } from "@/components/splash-intro";
import { Button, Card, Pill, SectionHeader } from "@/components/ui";
import { categories, cities, outings } from "@/lib/mock-data";

export default function LandingPage() {
  return (
    <main className="phone-shell min-h-screen">
      <SplashIntro />
      <div className="mx-auto max-w-xl px-4 py-6">
        <section className="relative overflow-hidden rounded-[36px] border border-white/10 bg-radial-premium p-6 shadow-card">
          <div className="absolute right-6 top-8 h-24 w-24 rounded-full bg-charge/20 blur-2xl" />
          <Pill>Boston live now</Pill>
          <h1 className="mt-5 text-5xl font-black leading-[0.95] text-white">
            Curated small-group outings for adults.
          </h1>
          <p className="mt-5 text-base leading-7 text-mist">
            Pick an outing or ask Social Battery for suggestions. We handle matching,
            tickets, group timing, reminders, and the post-outing feedback loop.
          </p>
          <div className="mt-6 flex flex-col gap-3 sm:flex-row">
            <Button href="/auth/signup">Join Social Battery</Button>
            <Button href="/home" variant="secondary">
              Preview app
            </Button>
          </div>
          <div className="mt-8 grid grid-cols-3 gap-3">
            {["3-6", "1 hour", "Mutual"].map((item, index) => (
              <div className="rounded-3xl bg-white/10 p-4" key={item}>
                <p className="text-2xl font-black text-charge">{item}</p>
                <p className="mt-1 text-xs text-mist">
                  {index === 0 && "people per group"}
                  {index === 1 && "before chat opens"}
                  {index === 2 && "friend DM unlock"}
                </p>
              </div>
            ))}
          </div>
        </section>

        <section className="mt-8">
          <SectionHeader eyebrow="How it works" title="Social plans, less planning" />
          <div className="grid gap-3">
            {[
              "Browse Boston outings or ask for suggestions.",
              "Book with one-off, category pass, or all-access pricing.",
              "Get placed into a balanced 3-6 person group.",
              "Chat opens 1 hour before the outing and closes at outing end time.",
              "After feedback, mutual become friends unlocks direct messages."
            ].map((step, index) => (
              <Card className="flex items-center gap-4" key={step}>
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-charge/15 font-black text-charge">
                  {index + 1}
                </span>
                <p className="text-sm leading-6 text-mist">{step}</p>
              </Card>
            ))}
          </div>
        </section>

        <section className="mt-8">
          <SectionHeader eyebrow="Launch categories" title="Choose your charge" />
          <div className="grid grid-cols-2 gap-3">
            {categories.map((category) => (
              <Card className="min-h-32" key={category}>
                <p className="text-lg font-bold text-white">{category}</p>
                <p className="mt-3 text-sm text-mist">
                  Curated {category.toLowerCase()} outings with small-group matching.
                </p>
              </Card>
            ))}
          </div>
        </section>

        <section className="mt-8">
          <SectionHeader eyebrow="Markets" title="City selector" />
          <div className="grid gap-3">
            {cities.map((city) => (
              <Card className="flex items-center justify-between" key={city.id}>
                <div>
                  <p className="font-bold text-white">
                    {city.name}, {city.state}
                  </p>
                  <p className="text-sm text-mist">
                    {city.status === "live" ? "Live launch city" : "Future waitlist market"}
                  </p>
                </div>
                <Pill tone={city.status === "live" ? "good" : "muted"}>{city.status}</Pill>
              </Card>
            ))}
          </div>
        </section>

        <section className="mt-8 pb-10">
          <SectionHeader eyebrow="Pricing preview" title="Sample Boston outing" />
          <OutingCard outing={outings[0]} />
        </section>
      </div>
    </main>
  );
}
