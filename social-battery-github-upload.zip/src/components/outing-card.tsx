import Link from "next/link";
import type { Outing } from "@/lib/types";
import { Card, Pill } from "./ui";

export function OutingCard({ outing }: { outing: Outing }) {
  return (
    <Link href={`/outings/${outing.id}`}>
      <Card className="transition hover:border-charge/30 hover:bg-white/[0.08]">
        <div className="flex items-start justify-between gap-4">
          <div>
            <Pill>{outing.category}</Pill>
            <h3 className="mt-3 text-lg font-bold text-white">{outing.title}</h3>
            <p className="mt-2 text-sm text-mist">
              {outing.dateLabel} at {outing.timeLabel} · {outing.neighborhood}
            </p>
          </div>
          <div className="rounded-2xl bg-white/10 px-3 py-2 text-right">
            <p className="text-xs text-mist">From</p>
            <p className="font-bold text-charge">${outing.prices.allAccess}</p>
          </div>
        </div>
        <div className="mt-4 grid grid-cols-3 gap-2 text-xs text-mist">
          <span className="rounded-2xl bg-white/[0.06] px-3 py-2">{outing.venue}</span>
          <span className="rounded-2xl bg-white/[0.06] px-3 py-2">{outing.groupSize}</span>
          <span className="rounded-2xl bg-white/[0.06] px-3 py-2">{outing.spotsLeft} spots</span>
        </div>
      </Card>
    </Link>
  );
}
