export type SupabaseReadyConfig = {
  url?: string;
  anonKey?: string;
};

export function createSupabaseClient(_config?: SupabaseReadyConfig) {
  return {
    mode: "mock",
    note: "Replace this adapter with the real Supabase client in Phase 2."
  };
}
