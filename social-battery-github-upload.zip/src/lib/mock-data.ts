import type { AdminMetric, City, Group, Outing } from "./types";

export const cities: City[] = [
  { id: "bos", name: "Boston", state: "MA", status: "live" },
  { id: "wor", name: "Worcester", state: "MA", status: "waitlist" },
  { id: "pvd", name: "Providence", state: "RI", status: "waitlist" }
];

export const categories = ["Movies", "Comedy", "Sports", "Performing Arts"] as const;

export const outings: Outing[] = [
  {
    id: "movie-dessert",
    title: "Indie Movie + Dessert After",
    category: "Movies",
    city: "Boston",
    neighborhood: "Coolidge Corner",
    venue: "Coolidge Corner Theatre",
    dateLabel: "Fri, Jul 18",
    timeLabel: "7:00 PM",
    endTimeLabel: "10:15 PM",
    groupSize: "3-6 people",
    spotsLeft: 4,
    status: "recommended",
    mood: "Low-pressure, cozy, easy conversation",
    description:
      "A curated film night with a small Social Battery group and dessert nearby after the credits.",
    included: ["Movie ticket", "Dessert reservation", "Dessert included", "Group coordination"],
    notIncluded: ["Extra concessions", "Transportation", "Alcoholic drinks"],
    extras: ["Dessert table held for the group", "Conversation prompt card in-app"],
    accessibility: "Theater has wheelchair seating. Dessert spot has step-free entry.",
    cancellation: "Cancel before the cutoff to avoid late cancellation review.",
    prices: { oneOff: 38, categoryPass: 33, allAccess: 28, discounted: 19 }
  },
  {
    id: "comedy-room",
    title: "Comedy Cellar-Style Showcase",
    category: "Comedy",
    city: "Boston",
    neighborhood: "Seaport",
    venue: "Laugh Boston",
    dateLabel: "Sat, Jul 19",
    timeLabel: "8:30 PM",
    endTimeLabel: "10:00 PM",
    groupSize: "3-6 people",
    spotsLeft: 3,
    status: "open",
    mood: "High-energy, playful, easy icebreakers",
    description:
      "A fast-moving comedy showcase with an optional post-show bar reservation nearby.",
    included: ["Show ticket", "Reserved group seating where available", "Optional bar reservation"],
    notIncluded: ["Two-item minimum", "Extra food or drinks", "Transportation"],
    extras: ["Nearby table option after the show"],
    accessibility: "Venue has accessible seating by request.",
    cancellation: "Late cancellations may be reviewed if the seat cannot be filled.",
    prices: { oneOff: 44, categoryPass: 38, allAccess: 31, discounted: 24 }
  },
  {
    id: "sox-night",
    title: "Fenway Night Game",
    category: "Sports",
    city: "Boston",
    neighborhood: "Fenway",
    venue: "Fenway Park",
    dateLabel: "Tue, Jul 22",
    timeLabel: "7:10 PM",
    endTimeLabel: "10:20 PM",
    groupSize: "3-6 people",
    spotsLeft: 5,
    status: "open",
    mood: "Loud, classic Boston, team-friendly",
    description:
      "A small-group baseball night with meetup guidance and in-app ticket delivery notes.",
    included: ["Game ticket", "Pre-game meetup point", "Group coordination"],
    notIncluded: ["Food", "Drinks", "Merchandise"],
    extras: ["Optional pre-game snack meetup"],
    accessibility: "Accessible seating depends on ticket block; admin review required.",
    cancellation: "Tickets are limited. Credits depend on refill availability.",
    prices: { oneOff: 58, categoryPass: 51, allAccess: 45, discounted: 32 }
  },
  {
    id: "orchestra-night",
    title: "Symphony Night + Cafe Walk",
    category: "Performing Arts",
    city: "Boston",
    neighborhood: "Back Bay",
    venue: "Symphony Hall",
    dateLabel: "Thu, Jul 24",
    timeLabel: "7:30 PM",
    endTimeLabel: "9:45 PM",
    groupSize: "3-6 people",
    spotsLeft: 2,
    status: "recommended",
    mood: "Refined, curious, conversation-rich",
    description:
      "A premium performing arts night with a nearby cafe walk for anyone who wants to keep talking.",
    included: ["Performance ticket", "Cafe reservation", "Group coordination"],
    notIncluded: ["Cafe purchases", "Transportation"],
    extras: ["Optional cafe stop after the performance"],
    accessibility: "Venue has elevators and accessible seating options.",
    cancellation: "Cancel before the cutoff to avoid penalty review.",
    prices: { oneOff: 62, categoryPass: 54, allAccess: 48, discounted: 35 }
  },
  {
    id: "improv-sunday",
    title: "Sunday Improv + Snacks",
    category: "Comedy",
    city: "Boston",
    neighborhood: "Cambridge",
    venue: "ImprovBoston Pop-Up",
    dateLabel: "Sun, Jul 27",
    timeLabel: "6:00 PM",
    endTimeLabel: "8:00 PM",
    groupSize: "3-6 people",
    spotsLeft: 6,
    status: "open",
    mood: "Light, silly, low-stakes",
    description: "An early comedy outing designed for easy Sunday social energy.",
    included: ["Show ticket", "Shared snack plate", "Group coordination"],
    notIncluded: ["Additional food", "Transportation"],
    extras: ["Alcohol-free friendly option"],
    accessibility: "Step-free entrance available.",
    cancellation: "Standard cancellation settings apply.",
    prices: { oneOff: 35, categoryPass: 30, allAccess: 25, discounted: 18 }
  },
  {
    id: "museum-film",
    title: "Museum Film Screening",
    category: "Movies",
    city: "Boston",
    neighborhood: "Fenway",
    venue: "Museum of Fine Arts",
    dateLabel: "Wed, Jul 30",
    timeLabel: "6:45 PM",
    endTimeLabel: "9:00 PM",
    groupSize: "3-6 people",
    spotsLeft: 4,
    status: "open",
    mood: "Artful, calm, thoughtful",
    description: "A film screening with a short gallery walk prompt before showtime.",
    included: ["Screening ticket", "Gallery prompt", "Group coordination"],
    notIncluded: ["Food", "Drinks", "Transportation"],
    extras: ["Optional gallery meet-up"],
    accessibility: "Museum is accessible with elevators and ramps.",
    cancellation: "Credits depend on timing and seat transfer options.",
    prices: { oneOff: 42, categoryPass: 36, allAccess: 31, discounted: 22 }
  },
  {
    id: "soccer-watch",
    title: "Soccer Watch Party",
    category: "Sports",
    city: "Boston",
    neighborhood: "South End",
    venue: "Parlor Sports",
    dateLabel: "Sat, Aug 2",
    timeLabel: "3:00 PM",
    endTimeLabel: "5:00 PM",
    groupSize: "3-6 people",
    spotsLeft: 5,
    status: "waitlist",
    mood: "Casual, loud, fan-friendly",
    description: "A lively watch-party setup for fans and curious first-timers.",
    included: ["Reserved group space", "Shared appetizer", "Group coordination"],
    notIncluded: ["Additional food", "Drinks", "Transportation"],
    extras: ["Alcohol-free follow-up available"],
    accessibility: "Ground-floor venue. Noise level may be high.",
    cancellation: "Waitlist bookings are confirmed after group balance review.",
    prices: { oneOff: 32, categoryPass: 28, allAccess: 22, discounted: 16 }
  },
  {
    id: "black-box",
    title: "Black Box Theater Night",
    category: "Performing Arts",
    city: "Boston",
    neighborhood: "South End",
    venue: "Boston Center for the Arts",
    dateLabel: "Fri, Aug 8",
    timeLabel: "7:30 PM",
    endTimeLabel: "9:30 PM",
    groupSize: "3-6 people",
    spotsLeft: 3,
    status: "open",
    mood: "Creative, intimate, discussion-ready",
    description: "A small theater outing with a built-in post-show conversation moment.",
    included: ["Theater ticket", "Post-show meetup point", "Group coordination"],
    notIncluded: ["Food", "Drinks", "Transportation"],
    extras: ["Cast talkback if available"],
    accessibility: "Accessibility varies by stage setup; admin confirms before booking.",
    cancellation: "Standard cancellation settings apply.",
    prices: { oneOff: 46, categoryPass: 40, allAccess: 34, discounted: 25 }
  }
];

export const groups: Group[] = [
  {
    id: "group-film-01",
    outingId: "movie-dessert",
    status: "confirmed",
    chatOpens: "1 hour before the outing",
    chatCloses: "At outing end time",
    members: [
      {
        firstName: "Maya",
        photoInitial: "M",
        prompts: [
          { label: "Occupation", answer: "UX researcher" },
          { label: "Fun fact", answer: "Can name most Oscar Best Picture winners." },
          { label: "Last movie", answer: "Past Lives" }
        ]
      },
      {
        firstName: "Andre",
        photoInitial: "A",
        prompts: [
          { label: "Sports interests", answer: "Celtics, soccer, and playoff chaos." },
          { label: "Dream job", answer: "Travel food critic" },
          { label: "Last trip", answer: "Montreal for a long weekend." }
        ]
      },
      {
        firstName: "Nina",
        photoInitial: "N",
        prompts: [
          { label: "Types of art", answer: "Film photography and street murals." },
          { label: "Fun fact", answer: "Keeps a ranking of Boston cannoli." },
          { label: "Work style", answer: "People first, spreadsheets second." }
        ]
      }
    ]
  },
  {
    id: "group-comedy-02",
    outingId: "comedy-room",
    status: "chat_open",
    chatOpens: "Open now",
    chatCloses: "At outing end time",
    members: []
  },
  {
    id: "group-arts-03",
    outingId: "orchestra-night",
    status: "pending",
    chatOpens: "After group confirmation",
    chatCloses: "At outing end time",
    members: []
  }
];

export const adminMetrics: AdminMetric[] = [
  { label: "Groups below 3", value: "2", tone: "critical" },
  { label: "Fill-risk outings", value: "5", tone: "warning" },
  { label: "Starts in 24 hours", value: "3", tone: "neutral" },
  { label: "Active chat windows", value: "1", tone: "good" },
  { label: "Low feedback flags", value: "4", tone: "warning" },
  { label: "One-sided friend flags", value: "7", tone: "warning" },
  { label: "ID reviews pending", value: "11", tone: "critical" },
  { label: "Discount reviews", value: "6", tone: "critical" },
  { label: "No-shows pending", value: "3", tone: "warning" },
  { label: "Credit decisions", value: "$428", tone: "neutral" },
  { label: "Payment issues", value: "2", tone: "critical" },
  { label: "Boston demand", value: "High", tone: "good" }
];

export const currentUser = {
  firstName: "Bryon",
  city: "Boston",
  points: 1240,
  credits: 24,
  membership: "All Access preview",
  idStatus: "Pending manual review",
  discountStatus: "Not applied",
  notifications: "Group and feedback reminders on"
};
