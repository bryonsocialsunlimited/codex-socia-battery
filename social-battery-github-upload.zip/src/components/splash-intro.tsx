"use client";

import { useEffect, useState } from "react";

export function SplashIntro() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const alreadyShown = window.sessionStorage.getItem("social-battery-intro");

    if (reduced || alreadyShown) {
      return;
    }

    setVisible(true);
    window.sessionStorage.setItem("social-battery-intro", "shown");
    const timer = window.setTimeout(() => setVisible(false), 4000);

    return () => window.clearTimeout(timer);
  }, []);

  if (!visible) {
    return null;
  }

  return (
    <button
      aria-label="Skip Social Battery intro"
      className="intro-fade fixed inset-0 z-50 grid place-items-center overflow-hidden bg-night text-left"
      onClick={() => setVisible(false)}
      type="button"
    >
      <div className="absolute inset-0 bg-radial-premium" />
      <div className="node-ring absolute h-80 w-80 rounded-full border border-charge/20">
        {Array.from({ length: 8 }).map((_, index) => (
          <span
            className="absolute h-3 w-3 rounded-full bg-charge shadow-[0_0_24px_rgba(32,243,210,.8)]"
            key={index}
            style={{
              left: `${50 + Math.cos((index / 8) * Math.PI * 2) * 47}%`,
              top: `${50 + Math.sin((index / 8) * Math.PI * 2) * 47}%`
            }}
          />
        ))}
      </div>
      <div className="battery-core relative grid h-44 w-32 place-items-center rounded-[2rem] border border-charge/50 bg-white/10 shadow-[0_0_80px_rgba(32,243,210,.35)] backdrop-blur-xl">
        <span className="absolute -right-3 top-12 h-12 w-3 rounded-r-lg bg-charge/70" />
        <div className="h-28 w-20 rounded-[1.4rem] bg-gradient-to-t from-charge via-pulse to-ember opacity-90" />
      </div>
      <div className="absolute bottom-16 text-center">
        <p className="text-xs font-semibold uppercase tracking-[0.32em] text-charge">
          Curating your charge
        </p>
        <h1 className="mt-3 text-4xl font-black text-white">Social Battery</h1>
        <p className="mt-2 text-sm text-mist">Tap anywhere to skip</p>
      </div>
    </button>
  );
}
