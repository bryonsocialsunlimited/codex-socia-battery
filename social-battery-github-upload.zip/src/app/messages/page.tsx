import { AppShell } from "@/components/app-shell";
import { Button, Card, Pill, SectionHeader } from "@/components/ui";

export default function MessagesPage() {
  return (
    <AppShell
      title="Messages"
      subtitle="Group chats are time-limited. Direct messages require mutual become friends."
    >
      <div className="space-y-6">
        <Card>
          <SectionHeader title="Locked group chat" action={<Pill tone="warning">Locked</Pill>} />
          <h3 className="text-lg font-bold text-white">Indie Movie + Dessert After</h3>
          <p className="mt-2 text-sm leading-6 text-mist">
            Chat is visible but input is disabled until 1 hour before the outing.
          </p>
          <div className="mt-4 rounded-2xl bg-white/[0.06] p-4 text-sm text-mist">
            Opens Jul 18 at 6:00 PM. Closes at outing end time.
          </div>
        </Card>

        <Card>
          <SectionHeader title="Active group chat" action={<Pill tone="good">Open now</Pill>} />
          <div className="space-y-3">
            {[
              ["Team", "Reminder: meet near the front entrance 10 minutes early."],
              ["Maya", "I am on the train now. See everyone soon."],
              ["Andre", "I grabbed the table reservation details."]
            ].map(([name, body]) => (
              <div className="rounded-2xl bg-white/[0.06] p-3" key={body}>
                <p className="text-xs font-semibold uppercase tracking-[0.14em] text-charge">
                  {name}
                </p>
                <p className="mt-1 text-sm text-mist">{body}</p>
              </div>
            ))}
          </div>
          <div className="mt-4 rounded-full border border-white/10 bg-white/[0.06] px-4 py-3 text-sm text-mist">
            Message input placeholder
          </div>
        </Card>

        <Card>
          <SectionHeader title="Post-friendship DMs" action={<Pill tone="muted">Placeholder</Pill>} />
          <p className="text-sm leading-6 text-mist">
            Direct messages are not available before or during a first outing. Mutual yes in the
            post-outing become friends flow unlocks DMs and deeper profile visibility.
          </p>
          <Button className="mt-4 w-full" variant="secondary">
            View friendship rules
          </Button>
        </Card>
      </div>
    </AppShell>
  );
}
