import { AppShell } from "@/components/app-shell";
import { Card, Pill, SectionHeader, SelectPill } from "@/components/ui";
import { adminMetrics } from "@/lib/mock-data";
import type { AdminMetric } from "@/lib/types";

function toneForMetric(tone: AdminMetric["tone"]) {
  if (tone === "critical") return "critical";
  if (tone === "warning") return "warning";
  if (tone === "good") return "good";
  return "muted";
}

export default function AdminPage() {
  const tabs = [
    "Metrics",
    "Outings",
    "Users",
    "Groups",
    "Feedback Flags",
    "ID Verification",
    "Discounted Access",
    "Payments/Credits",
    "Rewards",
    "City Demand",
    "Settings"
  ];

  return (
    <AppShell
      title="Admin"
      subtitle="High-need metrics and action queues first."
      right={<Pill tone="critical">Internal</Pill>}
    >
      <div className="space-y-6">
        <section>
          <SectionHeader eyebrow="Action queue" title="Needs attention" />
          <div className="grid grid-cols-2 gap-3">
            {adminMetrics.map((metric) => (
              <Card className="p-4" key={metric.label}>
                <Pill tone={toneForMetric(metric.tone)}>{metric.value}</Pill>
                <p className="mt-3 text-sm font-semibold text-white">{metric.label}</p>
              </Card>
            ))}
          </div>
        </section>

        <Card>
          <SectionHeader title="Admin tabs" />
          <div className="grid gap-3">
            {tabs.map((tab) => (
              <SelectPill key={tab}>{tab}</SelectPill>
            ))}
          </div>
        </Card>

        <Card>
          <SectionHeader title="Manual controls placeholder" />
          <p className="text-sm leading-6 text-mist">
            Later phases connect outing creation, group adjustment, merge decisions, chat
            overrides, ID review, discounted access review, credits, points, and notification logs.
          </p>
        </Card>
      </div>
    </AppShell>
  );
}
