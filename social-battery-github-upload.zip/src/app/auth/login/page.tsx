import { Button, Card, Field, Pill } from "@/components/ui";

export default function LoginPage() {
  return (
    <main className="phone-shell grid min-h-screen place-items-center px-4 py-6">
      <div className="w-full max-w-xl">
        <Pill>Welcome back</Pill>
        <h1 className="mt-4 text-4xl font-black text-white">Log in</h1>
        <p className="mt-3 text-sm text-mist">
          Continue to your outings, group timing, rewards, and profile settings.
        </p>
        <Card className="mt-6 space-y-4">
          <Field label="Email" placeholder="you@example.com" type="email" />
          <Field label="Password" placeholder="Your password" type="password" />
          <Button className="w-full" href="/home">
            Log in
          </Button>
          <Button className="w-full" href="/auth/signup" variant="ghost">
            New here? Create an account
          </Button>
        </Card>
      </div>
    </main>
  );
}
