export const bottomNavItems = [
  { href: "/home", label: "Home", marker: "H" },
  { href: "/explore", label: "Explore", marker: "E" },
  { href: "/outings", label: "Outings", marker: "O" },
  { href: "/messages", label: "Messages", marker: "M" },
  { href: "/profile", label: "Profile", marker: "P" }
];
