import { Button, Card, Field, Pill, SelectPill } from "@/components/ui";
import { cities } from "@/lib/mock-data";

export default function SignupPage() {
  return (
    <main className="phone-shell min-h-screen px-4 py-6">
      <div className="mx-auto max-w-xl">
        <Pill>Account setup</Pill>
        <h1 className="mt-4 text-4xl font-black text-white">Join Social Battery</h1>
        <p className="mt-3 text-sm leading-6 text-mist">
          Email and password first. Last names stay private by default, and launch tracks are
          designed for 21+ adults.
        </p>
        <Card className="mt-6 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <Field label="First name" placeholder="Bryon" />
            <Field label="Last name" placeholder="Private" />
          </div>
          <Field label="Email" placeholder="you@example.com" type="email" />
          <Field label="Phone" placeholder="For reminders later" type="tel" />
          <Field label="Date of birth" placeholder="MM/DD/YYYY" />
          <div>
            <p className="mb-2 text-sm font-medium text-mist">City</p>
            <div className="grid gap-2">
              {cities.map((city) => (
                <SelectPill key={city.id}>
                  {city.name} · {city.status === "live" ? "live" : "waitlist"}
                </SelectPill>
              ))}
            </div>
          </div>
          <label className="flex items-start gap-3 rounded-2xl bg-white/[0.06] p-4 text-sm text-mist">
            <input className="mt-1" type="checkbox" />
            I acknowledge Social Battery safety, cancellation, no-show, and privacy expectations.
          </label>
          <Button className="w-full" href="/onboarding">
            Create account
          </Button>
          <Button className="w-full" href="/auth/login" variant="ghost">
            Already have an account? Log in
          </Button>
        </Card>
      </div>
    </main>
  );
}
