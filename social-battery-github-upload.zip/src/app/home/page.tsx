import { AppShell } from "@/components/app-shell";
import { OutingCard } from "@/components/outing-card";
import { Button, Card, Pill, SectionHeader } from "@/components/ui";
import { cities, currentUser, outings } from "@/lib/mock-data";

export default function HomePage() {
  const recommended = outings.filter((outing) => outing.status === "recommended");

  return (
    <AppShell
      title={`Hi, ${currentUser.firstName}`}
      subtitle="Boston is live. Worcester and Providence are collecting waitlist demand."
      right={<Pill tone="good">{currentUser.points} pts</Pill>}
    >
      <div className="space-y-6">
        <Card className="bg-gradient-to-br from-charge/15 to-pulse/10">
          <div className="flex items-start justify-between gap-4">
            <div>
              <Pill>Next outing</Pill>
              <h2 className="mt-3 text-2xl font-black text-white">Indie Movie + Dessert After</h2>
              <p className="mt-2 text-sm text-mist">
                Group confirmed · chat opens 1 hour before the outing.
              </p>
            </div>
            <span className="rounded-2xl bg-white/10 px-3 py-2 text-sm font-bold text-charge">
              Jul 18
            </span>
          </div>
          <Button className="mt-5 w-full" href="/groups/group-film-01">
            Preview group
          </Button>
        </Card>

        <Card>
          <SectionHeader title="City selector" />
          <div className="grid gap-3">
            {cities.map((city) => (
              <div className="flex items-center justify-between rounded-2xl bg-white/[0.06] p-3" key={city.id}>
                <span className="font-semibold text-white">{city.name}</span>
                <Pill tone={city.status === "live" ? "good" : "muted"}>{city.status}</Pill>
              </div>
            ))}
          </div>
        </Card>

        <section>
          <SectionHeader eyebrow="Recommended" title="Outings for your current charge" />
          <div className="space-y-4">
            {recommended.map((outing) => (
              <OutingCard outing={outing} key={outing.id} />
            ))}
          </div>
        </section>

        <Card>
          <SectionHeader title="Quick actions" />
          <div className="grid grid-cols-2 gap-3">
            <Button href="/explore" variant="secondary">
              Explore
            </Button>
            <Button href="/onboarding" variant="secondary">
              Complete profile
            </Button>
            <Button href="/profile" variant="secondary">
              Apply discount
            </Button>
            <Button href="/outings" variant="secondary">
              View outings
            </Button>
          </div>
        </Card>
      </div>
    </AppShell>
  );
}
