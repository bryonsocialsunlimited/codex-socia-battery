import Link from "next/link";
import type { ReactNode } from "react";

export function cn(...classes: Array<string | false | null | undefined>) {
  return classes.filter(Boolean).join(" ");
}

export function Button({
  children,
  href,
  variant = "primary",
  className = ""
}: {
  children: ReactNode;
  href?: string;
  variant?: "primary" | "secondary" | "ghost";
  className?: string;
}) {
  const styles = cn(
    "inline-flex min-h-11 items-center justify-center rounded-full px-5 text-sm font-semibold transition active:scale-[0.98]",
    variant === "primary" &&
      "bg-gradient-to-r from-charge to-pulse text-night shadow-glow",
    variant === "secondary" &&
      "border border-white/10 bg-white/10 text-white hover:bg-white/15",
    variant === "ghost" && "text-mist hover:text-white",
    className
  );

  if (href) {
    return (
      <Link className={styles} href={href}>
        {children}
      </Link>
    );
  }

  return <button className={styles}>{children}</button>;
}

export function Card({
  children,
  className = ""
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <section className={cn("glass rounded-[28px] p-5", className)}>
      {children}
    </section>
  );
}

export function Pill({
  children,
  tone = "default",
  className = ""
}: {
  children: ReactNode;
  tone?: "default" | "good" | "warning" | "critical" | "muted";
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.12em]",
        tone === "default" && "border-charge/30 bg-charge/10 text-charge",
        tone === "good" && "border-lime/30 bg-lime/10 text-lime",
        tone === "warning" && "border-ember/30 bg-ember/10 text-ember",
        tone === "critical" && "border-red-400/30 bg-red-500/10 text-red-200",
        tone === "muted" && "border-white/10 bg-white/5 text-mist",
        className
      )}
    >
      {children}
    </span>
  );
}

export function SectionHeader({
  eyebrow,
  title,
  action
}: {
  eyebrow?: string;
  title: string;
  action?: ReactNode;
}) {
  return (
    <div className="mb-4 flex items-end justify-between gap-4">
      <div>
        {eyebrow ? (
          <p className="mb-1 text-xs font-semibold uppercase tracking-[0.18em] text-charge">
            {eyebrow}
          </p>
        ) : null}
        <h2 className="text-xl font-bold text-white">{title}</h2>
      </div>
      {action}
    </div>
  );
}

export function Field({
  label,
  placeholder,
  type = "text"
}: {
  label: string;
  placeholder: string;
  type?: string;
}) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm font-medium text-mist">{label}</span>
      <input
        className="min-h-12 w-full rounded-2xl border border-white/10 bg-white/[0.06] px-4 text-white outline-none ring-charge/40 transition placeholder:text-mist/50 focus:border-charge/40 focus:ring-4"
        placeholder={placeholder}
        type={type}
      />
    </label>
  );
}

export function SelectPill({ children }: { children: ReactNode }) {
  return (
    <button className="rounded-2xl border border-white/10 bg-white/[0.06] px-4 py-3 text-left text-sm text-white transition hover:border-charge/30 hover:bg-charge/10">
      {children}
    </button>
  );
}
