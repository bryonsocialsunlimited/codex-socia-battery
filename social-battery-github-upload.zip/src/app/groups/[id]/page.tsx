import { notFound } from "next/navigation";
import { AppShell } from "@/components/app-shell";
import { Card, Pill, SectionHeader } from "@/components/ui";
import { getGroupChatRuleSummary } from "@/lib/adapters/messaging";
import { groups, outings } from "@/lib/mock-data";

export default function GroupPreviewPage({ params }: { params: { id: string } }) {
  const group = groups.find((item) => item.id === params.id);

  if (!group) {
    notFound();
  }

  const outing = outings.find((item) => item.id === group.outingId);
  const rules = getGroupChatRuleSummary();

  return (
    <AppShell
      title="Group preview"
      subtitle="First names and 3 approved public prompts only."
      right={<Pill tone={group.status === "confirmed" ? "good" : "warning"}>{group.status}</Pill>}
    >
      <div className="space-y-6">
        <Card>
          <Pill>{outing?.category ?? "Outing"}</Pill>
          <h2 className="mt-3 text-2xl font-black text-white">{outing?.title}</h2>
          <p className="mt-2 text-sm text-mist">
            Groups are designed for 3-6 people and never exceed 6.
          </p>
          <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
            <div className="rounded-2xl bg-white/[0.06] p-3">
              <p className="text-xs text-mist">Chat opens</p>
              <p className="mt-1 font-semibold text-white">{group.chatOpens}</p>
            </div>
            <div className="rounded-2xl bg-white/[0.06] p-3">
              <p className="text-xs text-mist">Chat closes</p>
              <p className="mt-1 font-semibold text-white">{group.chatCloses}</p>
            </div>
          </div>
        </Card>

        <section>
          <SectionHeader eyebrow="Members" title={`${group.members.length} of 6 visible`} />
          <div className="space-y-4">
            {group.members.map((member) => (
              <Card key={member.firstName}>
                <div className="flex items-center gap-4">
                  <div className="grid h-14 w-14 place-items-center rounded-3xl bg-gradient-to-br from-charge to-pulse text-xl font-black text-night">
                    {member.photoInitial}
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white">{member.firstName}</h3>
                    <p className="text-sm text-mist">Last name and private profile hidden.</p>
                  </div>
                </div>
                <div className="mt-4 space-y-2">
                  {member.prompts.slice(0, 3).map((prompt) => (
                    <div className="rounded-2xl bg-white/[0.06] p-3" key={prompt.label}>
                      <p className="text-xs font-semibold uppercase tracking-[0.14em] text-charge">
                        {prompt.label}
                      </p>
                      <p className="mt-1 text-sm text-mist">{prompt.answer}</p>
                    </div>
                  ))}
                </div>
              </Card>
            ))}
          </div>
        </section>

        <Card>
          <SectionHeader title="Messaging rules" />
          <div className="space-y-3 text-sm leading-6 text-mist">
            <p>{rules.opens}</p>
            <p>{rules.closes}</p>
            <p>{rules.dmUnlock}</p>
            <p>Admin can open early or extend a group chat if needed.</p>
          </div>
        </Card>
      </div>
    </AppShell>
  );
}
