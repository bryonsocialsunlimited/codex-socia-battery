export function getGroupChatRuleSummary() {
  return {
    opens: "Group chat opens 1 hour before the outing.",
    closes: "Group chat closes at outing end time.",
    dmUnlock: "Direct messages unlock only after mutual become friends consent."
  };
}
