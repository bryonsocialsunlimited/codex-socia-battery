import { AppShell } from "@/components/app-shell";
import { OutingCard } from "@/components/outing-card";
import { Button, Card, Pill, SectionHeader, SelectPill } from "@/components/ui";
import { categories, outings } from "@/lib/mock-data";

export default function ExplorePage() {
  return (
    <AppShell title="Explore" subtitle="Browse Boston outings or ask for broad suggestions.">
      <div className="space-y-6">
        <Card>
          <SectionHeader title="Categories" action={<Pill>Boston</Pill>} />
          <div className="grid grid-cols-2 gap-3">
            {categories.map((category) => (
              <SelectPill key={category}>{category}</SelectPill>
            ))}
          </div>
        </Card>

        <Card>
          <SectionHeader title="Filters" action={<Pill tone="muted">Map/list later</Pill>} />
          <div className="grid grid-cols-2 gap-3">
            {["City", "Date/time", "Budget", "Social preference"].map((filter) => (
              <SelectPill key={filter}>{filter}</SelectPill>
            ))}
          </div>
          <div className="mt-3 rounded-2xl border border-charge/20 bg-charge/10 p-4">
            <p className="font-semibold text-white">Alcohol-free preference</p>
            <p className="mt-1 text-sm text-mist">
              Toggle placeholder with follow-up question for hard preferences.
            </p>
          </div>
        </Card>

        <Card>
          <SectionHeader title="Need a suggestion?" />
          <p className="text-sm leading-6 text-mist">
            The MVP will use profile preferences, availability, budget, and hard constraints.
            This shell keeps the suggestion engine mocked and transparent.
          </p>
          <Button className="mt-4 w-full">Ask Social Battery</Button>
        </Card>

        <section>
          <SectionHeader eyebrow="Suggested for you" title="Boston outings" />
          <div className="space-y-4">
            {outings.map((outing) => (
              <OutingCard outing={outing} key={outing.id} />
            ))}
          </div>
        </section>
      </div>
    </AppShell>
  );
}
