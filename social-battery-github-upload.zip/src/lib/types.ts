export type CityStatus = "live" | "waitlist" | "future";

export type City = {
  id: string;
  name: string;
  state: string;
  status: CityStatus;
};

export type OutingCategory = "Movies" | "Comedy" | "Sports" | "Performing Arts";

export type PriceOptions = {
  oneOff: number;
  categoryPass: number;
  allAccess: number;
  discounted?: number;
};

export type Outing = {
  id: string;
  title: string;
  category: OutingCategory;
  city: string;
  neighborhood: string;
  venue: string;
  dateLabel: string;
  timeLabel: string;
  endTimeLabel: string;
  groupSize: string;
  spotsLeft: number;
  status: "recommended" | "open" | "waitlist" | "confirmed" | "past";
  mood: string;
  description: string;
  included: string[];
  notIncluded: string[];
  extras: string[];
  accessibility: string;
  cancellation: string;
  prices: PriceOptions;
};

export type GroupMember = {
  firstName: string;
  photoInitial: string;
  prompts: { label: string; answer: string }[];
};

export type Group = {
  id: string;
  outingId: string;
  status: "pending" | "confirmed" | "chat_open" | "closed";
  chatOpens: string;
  chatCloses: string;
  members: GroupMember[];
};

export type AdminMetric = {
  label: string;
  value: string;
  tone: "critical" | "warning" | "good" | "neutral";
};
