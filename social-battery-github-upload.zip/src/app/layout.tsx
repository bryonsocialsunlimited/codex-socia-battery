import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Social Battery",
  description: "Curated small-group outings in Boston."
};

export default function RootLayout({
  children
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
