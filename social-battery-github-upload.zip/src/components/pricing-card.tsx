import type { Outing } from "@/lib/types";
import { Button, Card, Field, Pill } from "./ui";

export function PricingCard({ outing }: { outing: Outing }) {
  const rows = [
    { label: "One-off outing", price: outing.prices.oneOff, note: "Regular booking" },
    {
      label: "Category Pass",
      price: outing.prices.categoryPass,
      note: "Member price with $16/month category pass"
    },
    {
      label: "All Access Pass",
      price: outing.prices.allAccess,
      note: "Best price with $60/month all-access membership"
    }
  ];

  return (
    <Card>
      <div className="mb-4 flex items-center justify-between">
        <h3 className="text-lg font-bold text-white">Pricing options</h3>
        <Pill tone="good">Editable later</Pill>
      </div>
      <div className="space-y-3">
        {rows.map((row) => (
          <div
            className="flex items-center justify-between gap-4 rounded-3xl border border-white/10 bg-white/[0.06] p-4"
            key={row.label}
          >
            <div>
              <p className="font-semibold text-white">{row.label}</p>
              <p className="mt-1 text-xs text-mist">{row.note}</p>
            </div>
            <p className="text-xl font-black text-charge">${row.price}</p>
          </div>
        ))}
      </div>
      <div className="mt-4">
        <Field label="Discount or beta bypass code" placeholder="Try SOCIALBETA" />
      </div>
      <Button className="mt-4 w-full" href="/outings">
        Book this outing
      </Button>
      <p className="mt-3 text-xs leading-5 text-mist">
        Tickets are delivered in-app. Restaurant, bar, or cafe spending is separate unless
        explicitly included.
      </p>
    </Card>
  );
}
