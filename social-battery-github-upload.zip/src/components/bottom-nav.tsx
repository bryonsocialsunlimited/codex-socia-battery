"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { bottomNavItems } from "@/lib/routes";
import { cn } from "./ui";

export function BottomNav() {
  const pathname = usePathname();

  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 mx-auto max-w-xl px-4 pb-4">
      <div className="glass grid grid-cols-5 rounded-[28px] p-2">
        {bottomNavItems.map((item) => {
          const active = pathname === item.href || pathname.startsWith(`${item.href}/`);

          return (
            <Link
              className={cn(
                "flex flex-col items-center gap-1 rounded-3xl px-2 py-2 text-[11px] font-semibold text-mist transition",
                active && "bg-white/[0.12] text-white shadow-glow"
              )}
              href={item.href}
              key={item.href}
            >
              <span
                className={cn(
                  "grid h-7 w-7 place-items-center rounded-full border border-white/10 bg-white/5 text-[12px]",
                  active && "border-charge/40 bg-charge/15 text-charge"
                )}
              >
                {item.marker}
              </span>
              {item.label}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
