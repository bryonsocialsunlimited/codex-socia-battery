import { notFound } from "next/navigation";
import { AppShell } from "@/components/app-shell";
import { PricingCard } from "@/components/pricing-card";
import { Card, Pill, SectionHeader } from "@/components/ui";
import { outings } from "@/lib/mock-data";

export default function OutingDetailPage({ params }: { params: { id: string } }) {
  const outing = outings.find((item) => item.id === params.id);

  if (!outing) {
    notFound();
  }

  return (
    <AppShell title={outing.title} subtitle={`${outing.city} · ${outing.neighborhood}`}>
      <div className="space-y-5">
        <Card>
          <div className="flex items-start justify-between gap-4">
            <div>
              <Pill>{outing.category}</Pill>
              <p className="mt-4 text-sm leading-6 text-mist">{outing.description}</p>
            </div>
            <div className="rounded-3xl bg-white/10 p-3 text-right">
              <p className="text-xs text-mist">Group</p>
              <p className="font-black text-charge">{outing.groupSize}</p>
            </div>
          </div>
          <div className="mt-5 grid grid-cols-2 gap-3 text-sm">
            {[
              ["Venue", outing.venue],
              ["Date", outing.dateLabel],
              ["Time", `${outing.timeLabel}-${outing.endTimeLabel}`],
              ["Availability", `${outing.spotsLeft} spots left`]
            ].map(([label, value]) => (
              <div className="rounded-2xl bg-white/[0.06] p-3" key={label}>
                <p className="text-xs text-mist">{label}</p>
                <p className="mt-1 font-semibold text-white">{value}</p>
              </div>
            ))}
          </div>
        </Card>

        <PricingCard outing={outing} />

        <Card>
          <SectionHeader title="What is included" />
          <ul className="space-y-2 text-sm text-mist">
            {outing.included.map((item) => (
              <li className="rounded-2xl bg-white/[0.06] px-4 py-3" key={item}>
                {item}
              </li>
            ))}
          </ul>
        </Card>

        <Card>
          <SectionHeader title="Not included" />
          <ul className="space-y-2 text-sm text-mist">
            {outing.notIncluded.map((item) => (
              <li className="rounded-2xl bg-white/[0.06] px-4 py-3" key={item}>
                {item}
              </li>
            ))}
          </ul>
        </Card>

        <Card>
          <SectionHeader title="Extras, access, and rules" />
          <div className="space-y-3 text-sm leading-6 text-mist">
            <p>
              <span className="font-semibold text-white">Attached extras:</span>{" "}
              {outing.extras.join(", ")}
            </p>
            <p>
              <span className="font-semibold text-white">Accessibility:</span>{" "}
              {outing.accessibility}
            </p>
            <p>
              <span className="font-semibold text-white">Cancellation/no-show:</span>{" "}
              {outing.cancellation}
            </p>
            <p>
              <span className="font-semibold text-white">Ticket delivery:</span> Tickets are
              delivered in-app after booking and admin confirmation.
            </p>
          </div>
        </Card>
      </div>
    </AppShell>
  );
}
