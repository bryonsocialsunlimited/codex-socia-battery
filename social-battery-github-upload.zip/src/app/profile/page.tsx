import { AppShell } from "@/components/app-shell";
import { Card, Pill, SectionHeader, SelectPill } from "@/components/ui";
import { currentUser } from "@/lib/mock-data";

export default function ProfilePage() {
  const profileItems = [
    ["Credits", `$${currentUser.credits}`],
    ["Rewards/points", `${currentUser.points} points`],
    ["Memberships", currentUser.membership],
    ["Notifications", currentUser.notifications],
    ["Payment settings", "Mock Stripe-ready"],
    ["ID verification", currentUser.idStatus],
    ["Discounted access review", currentUser.discountStatus],
    ["Public prompts", "3 visible in groups"],
    ["Legal acknowledgments", "Signed at signup"],
    ["Contact support", "Placeholder"]
  ];

  return (
    <AppShell title="Profile" subtitle="Your account, visibility, rewards, and access settings.">
      <div className="space-y-6">
        <Card>
          <div className="flex items-center gap-4">
            <div className="grid h-20 w-20 place-items-center rounded-[2rem] bg-gradient-to-br from-charge to-pulse text-3xl font-black text-night">
              B
            </div>
            <div>
              <h2 className="text-2xl font-black text-white">{currentUser.firstName}</h2>
              <p className="text-sm text-mist">Boston · last name private by default</p>
              <div className="mt-2 flex flex-wrap gap-2">
                <Pill tone="good">{currentUser.points} pts</Pill>
                <Pill tone="muted">${currentUser.credits} credits</Pill>
              </div>
            </div>
          </div>
        </Card>

        <Card>
          <SectionHeader title="Account center" />
          <div className="grid gap-3">
            {profileItems.map(([label, value]) => (
              <SelectPill key={label}>
                <span className="flex items-center justify-between gap-3">
                  <span>{label}</span>
                  <span className="text-right text-mist">{value}</span>
                </span>
              </SelectPill>
            ))}
          </div>
        </Card>

        <Card>
          <SectionHeader title="Discounted access" action={<Pill tone="warning">Review queue</Pill>} />
          <p className="text-sm leading-6 text-mist">
            Applicants upload two proof methods. Admin can approve based on financial pressure,
            not only strict income.
          </p>
          <div className="mt-4 grid gap-3">
            <SelectPill>Upload proof method 1</SelectPill>
            <SelectPill>Upload proof method 2</SelectPill>
          </div>
        </Card>
      </div>
    </AppShell>
  );
}
