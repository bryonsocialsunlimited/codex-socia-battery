import { Button, Card, Field, Pill, SectionHeader, SelectPill } from "@/components/ui";
import { categories } from "@/lib/mock-data";

export default function OnboardingPage() {
  return (
    <main className="phone-shell min-h-screen px-4 py-6">
      <div className="mx-auto max-w-xl">
        <Pill>Onboarding start</Pill>
        <h1 className="mt-4 text-4xl font-black text-white">Tune your social battery</h1>
        <p className="mt-3 text-sm leading-6 text-mist">
          Mostly taps, sliders, and yes/no choices. Deeper profile details stay private unless
          mutual friendship unlocks more visibility later.
        </p>
        <div className="mt-6 space-y-5">
          <Card>
            <SectionHeader title="Your outing interests" />
            <div className="grid grid-cols-2 gap-3">
              {categories.map((category) => (
                <SelectPill key={category}>{category}</SelectPill>
              ))}
            </div>
          </Card>
          <Card>
            <SectionHeader title="Matching basics" />
            <div className="grid gap-3">
              {["Social energy", "Availability", "Budget comfort", "Transportation"].map(
                (item) => (
                  <SelectPill key={item}>{item}: choose preference</SelectPill>
                )
              )}
            </div>
          </Card>
          <Card>
            <SectionHeader title="Public prompts" />
            <p className="mb-4 text-sm leading-6 text-mist">
              Group previews reveal first names and only 3 approved public prompts.
            </p>
            <div className="space-y-3">
              <Field label="Occupation" placeholder="Optional public prompt" />
              <Field label="Fun fact" placeholder="Something easy to ask about" />
              <Field label="Last movie, show, or trip" placeholder="Conversation starter" />
            </div>
          </Card>
          <Card>
            <SectionHeader title="Manual ID verification" />
            <div className="grid gap-3">
              <SelectPill>Upload valid photo ID placeholder</SelectPill>
              <SelectPill>Upload selfie placeholder</SelectPill>
            </div>
            <p className="mt-3 text-xs leading-5 text-mist">
              MVP status can be pending, approved, rejected, or needs more info. Admin reviews
              manually.
            </p>
          </Card>
          <Button className="w-full" href="/home">
            Finish prototype onboarding
          </Button>
        </div>
      </div>
    </main>
  );
}
