import type { ReactNode } from "react";
import { BottomNav } from "./bottom-nav";
import { Pill } from "./ui";

export function AppShell({
  children,
  title,
  subtitle,
  right
}: {
  children: ReactNode;
  title: string;
  subtitle?: string;
  right?: ReactNode;
}) {
  return (
    <main className="phone-shell min-h-screen pb-28">
      <div className="mx-auto min-h-screen w-full max-w-xl px-4 pt-6">
        <header className="mb-6 flex items-start justify-between gap-4">
          <div>
            <Pill tone="muted">Social Battery</Pill>
            <h1 className="mt-3 text-3xl font-black text-white">{title}</h1>
            {subtitle ? <p className="mt-2 text-sm text-mist">{subtitle}</p> : null}
          </div>
          {right}
        </header>
        {children}
      </div>
      <BottomNav />
    </main>
  );
}
